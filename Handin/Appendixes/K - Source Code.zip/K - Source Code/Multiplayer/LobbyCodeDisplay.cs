using TMPro;
using UnityEngine;

public class LobbyCodeDisplay : MonoBehaviour
{
    public TMP_Text TMP_text;
    
    private void OnGUI()
    {
        if (MultiplayerManager.Instance == null) return;
        
        string code = MultiplayerManager.Instance.CurrentLobbyCode;
        
        if (!string.IsNullOrEmpty(code))
        {
            TMP_text.SetText("Lobby Code: " + code);
        }
    }
    // void OnGUI()
    // {
    //     if (MultiplayerManager.Instance == null) return;
    //     
    //     float w = 220f, h = 40f;
    //     float x = 10f, y = 10f;
    //     //float spacing = 10f;
    //
    //     string code = MultiplayerManager.Instance.CurrentLobbyCode;
    //
    //     if (!string.IsNullOrEmpty(code))
    //     {
    //         GUI.Label(new Rect(x, y, 300, h), "Lobby Code: " + code);
    //         if (GUI.Button(new Rect(x, y + (h + 10), w, h), "Leave lobby")) _ = MultiplayerManager.Instance.Disconnect();
    //     }
    // }
}