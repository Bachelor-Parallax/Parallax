using UnityEngine;
using Unity.Netcode;

[RequireComponent(typeof(Rigidbody))]
public class KeyInteractable : NetworkBehaviour, IInteractable, IActivationState
{
    [SerializeField] private string keyId = "ButtonKey";
    [SerializeField] private AudioClip keySound;
    [SerializeField] private float interactCooldown = 0.2f;
    
    private float _nextInteractTime;
    private NetworkVariable<bool> isCollected = new NetworkVariable<bool>(
    false,
    NetworkVariableReadPermission.Everyone,
    NetworkVariableWritePermission.Server
    );
    public bool IsCollected => isCollected.Value;
    public bool IsActivated => isCollected.Value;

    [SerializeField] private ObjectSound objectSound;
    private Rigidbody _rb;

    private Transform _holder;
    private Transform _holdPoint;
    
    private Collider _keyCollider;
    private Collider[] _playerColliders;
    private IInteractCondition[] conditions;

    private bool _isHeld;

    private void Awake()
    {
        _rb = GetComponent<Rigidbody>();
        _keyCollider = GetComponent<Collider>();
        _rb.collisionDetectionMode = CollisionDetectionMode.ContinuousSpeculative;
        conditions = GetComponents<IInteractCondition>();
        objectSound = GetComponent<ObjectSound>();
    }

    public bool CanInteract(GameObject interactor)
    {
        foreach (var condition in conditions)
        {
            if (!condition.IsMet(interactor))
                return false;
        }

        return true;
    }

    public void Interact(GameObject interactor)
    {
        if (Time.time < _nextInteractTime) return;
        _nextInteractTime = Time.time + interactCooldown;
        
        Debug.Log("Key Interact called, IsSpawned: " + IsSpawned);
        if (!IsSpawned) return;

        NetworkObject playerNetObj = interactor.GetComponent<NetworkObject>();
        if (playerNetObj == null) return;

        InteractServerRpc(playerNetObj.OwnerClientId);
    }
    
    [Rpc(SendTo.Server)]
    private void InteractServerRpc(ulong clientId)
    {
        NetworkObject playerObj =
            NetworkManager.Singleton.SpawnManager.GetPlayerNetworkObject(clientId);

        if (playerObj == null) return;

        RoleController role = playerObj.GetComponent<RoleController>();
        if (role == null) return;

        if (role.IsCat)
        {
            if (_isHeld)
                Drop(clientId);
            else
                Pickup(playerObj.gameObject);
        }
        else if (role.IsHuman)
        {
            CollectKey(clientId);
        }
    }

    private void keyCollected()
    {
        isCollected.Value = true;
        PlayKeySoundClientRpc();

        Debug.Log($"Picked up key: {keyId}");
    }

    [Rpc(SendTo.ClientsAndHost)]
    private void PlayKeySoundClientRpc()
    {
        objectSound?.PlayRandomPitch();
    }

    #region Cat Interaction
    
    private void Pickup(GameObject player)
    {
        MouthCarryPoint carry = player.GetComponentInChildren<MouthCarryPoint>();
        if (carry == null) return;

        _holdPoint = carry.MouthPoint;
        _isHeld = true;

        _rb.useGravity = false;
        _rb.isKinematic = true;

        _playerColliders = player.GetComponentsInChildren<Collider>();

        foreach (Collider col in _playerColliders)
            Physics.IgnoreCollision(_keyCollider, col, true);

        keyCollected();
        
        SyncPickupClientRpc(player.GetComponent<NetworkObject>().OwnerClientId);
    }

    private void Drop(ulong clientId)
    {
        _isHeld = false;

        if (_playerColliders != null)
        {
            foreach (Collider col in _playerColliders)
                Physics.IgnoreCollision(_keyCollider, col, false);
        }

        transform.position = _holdPoint.position + _holdPoint.forward * 0.2f + Vector3.up * 0.1f;

        _holdPoint = null;
        
        _rb.isKinematic = false;
        _rb.useGravity = true;
        
        _rb.linearVelocity = Vector3.zero;
        _rb.angularVelocity = Vector3.zero;

        SyncDropClientRpc(clientId);
        
        _playerColliders = null;
    }
    
    [Rpc(SendTo.ClientsAndHost)]
    private void SyncPickupClientRpc(ulong clientId)
    {
        NetworkObject playerObj =
            NetworkManager.Singleton.SpawnManager.GetPlayerNetworkObject(clientId);

        if (playerObj == null) return;

        Collider[] cols = playerObj.GetComponentsInChildren<Collider>();

        foreach (Collider col in cols)
            Physics.IgnoreCollision(_keyCollider, col, true);
    }
    
    [Rpc(SendTo.ClientsAndHost)]
    private void SyncDropClientRpc(ulong clientId)
    {
        NetworkObject playerObj =
            NetworkManager.Singleton.SpawnManager.GetPlayerNetworkObject(clientId);

        if (playerObj == null) return;

        Collider[] cols = playerObj.GetComponentsInChildren<Collider>();

        foreach (Collider col in cols)
            Physics.IgnoreCollision(_keyCollider, col, false);
    }
    
    #endregion
    
    #region Human Interaction
    private void CollectKey(ulong senderClientId)
    {
        isCollected.Value = true;

        keyCollected();

        Debug.Log($"Picked up key: {keyId} by client {senderClientId}");

        HideKeyClientRpc();
    }

    [Rpc(SendTo.ClientsAndHost)]
    private void HideKeyClientRpc()
    {
        if (_keyCollider != null)
            _keyCollider.enabled = false;

        Renderer[] renderers = GetComponentsInChildren<Renderer>();

        foreach (Renderer renderer in renderers)
            renderer.enabled = false;
    }
    #endregion

    private void LateUpdate()
    {
        if (!_isHeld || _holdPoint == null) return;

        transform.position = _holdPoint.position;
        transform.rotation = _holdPoint.rotation;
    }

    public string GetFailText(GameObject interactor)
    {
        RoleController role = interactor.GetComponent<RoleController>();

        foreach (IInteractCondition condition in conditions)
        {
            if (!condition.IsMet(interactor))
                return condition.FailText;
        }

        return "";
    }

    public string GetInteractText()
    {
        return _isHeld ? "Drop key" : "Pick up key";
    }
}